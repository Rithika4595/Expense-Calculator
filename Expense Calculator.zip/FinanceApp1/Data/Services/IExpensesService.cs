﻿using FinanceApp1.Models;

namespace FinanceApp1.Data.Services
{
    public interface IExpensesService
    {
        Task<IEnumerable<Expense>> GetAll();
        Task Add(Expense expense);
        IQueryable GetChartData();

    }
}
