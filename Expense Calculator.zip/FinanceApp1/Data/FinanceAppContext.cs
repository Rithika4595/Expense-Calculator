﻿using FinanceApp1.Models;
using Microsoft.EntityFrameworkCore;

namespace FinanceApp1.Data
{
    public class FinanceAppContext : DbContext
    {
        public FinanceAppContext(DbContextOptions<FinanceAppContext> options) : base(options) { }



       public DbSet<Expense> Expenses { get; set; }
    }
}
